import { NaryNode, NaryTree } from '../structures/NaryTree';
import {
  Dashboard,
  Help,
  Home,
  InventoryReport,
  Profile,
  Reports,
  SalesReport,
  Security,
  Settings,
} from '../pages/pages';

// Cada ítem del menú tiene: título, link y componente
const item = (title, link, component) => new NaryNode({ title, link, component });

// Raíz del árbol (no se muestra en el menú)
const root = item('Menú', '/', Home);

root.addChild(item('Dashboard', '/dashboard', Dashboard));

const reports = root.addChild(item('Reportes', '/reports', Reports));
reports.addChild(item('Ventas', '/reports/sales', SalesReport));
reports.addChild(item('Inventario', '/reports/inventory', InventoryReport));

const settings = root.addChild(item('Configuración', '/settings', Settings));
settings.addChild(item('Perfil', '/settings/profile', Profile));
settings.addChild(item('Seguridad', '/settings/security', Security));

root.addChild(item('Ayuda', '/help', Help));

export const menuTree = new NaryTree(root);
