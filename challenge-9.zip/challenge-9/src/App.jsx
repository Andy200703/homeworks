import { useEffect } from 'react';
import { Route, Routes } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import { menuTree } from './data/menuTree';
import { NotFound } from './pages/NotFound';

export default function App() {
  useEffect(() => {
    menuTree.print(); // DFS y BFS por consola
  }, []);

  // Una ruta por cada nodo del árbol (se obtiene con el recorrido DFS)
  const routes = menuTree.toArray();

  return (
    <div className="layout">
      <Sidebar tree={menuTree} />
      <main className="content">
        <Routes>
          {routes.map(({ link, component: Component }) => (
            <Route key={link} path={link} element={<Component />} />
          ))}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
    </div>
  );
}
