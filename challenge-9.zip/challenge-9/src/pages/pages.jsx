import { menuTree } from '../data/menuTree';

// Un componente por cada opción del menú
function Page({ title, children }) {
  return (
    <div className="card">
      <h1>{title}</h1>
      {children}
    </div>
  );
}

export function Home() {
  return (
    <Page title="Inicio">
      <p>Bienvenido. El menú lateral se genera recorriendo un árbol N-ario.</p>
      <h2>Recorridos del árbol</h2>
      <p>
        <strong>DFS:</strong> {menuTree.dfs().map((item) => item.title).join(' → ')}
      </p>
      <p>
        <strong>BFS:</strong> {menuTree.bfs().map((item) => item.title).join(' → ')}
      </p>
    </Page>
  );
}

export const Dashboard = () => (
  <Page title="Dashboard"><p>Resumen general de la aplicación.</p></Page>
);

export const Reports = () => (
  <Page title="Reportes"><p>Elige un reporte en el submenú.</p></Page>
);
export const SalesReport = () => (
  <Page title="Reporte de ventas"><p>Aquí irían las ventas del mes.</p></Page>
);
export const InventoryReport = () => (
  <Page title="Reporte de inventario"><p>Aquí iría el stock disponible.</p></Page>
);

export const Settings = () => (
  <Page title="Configuración"><p>Elige una opción en el submenú.</p></Page>
);
export const Profile = () => (
  <Page title="Perfil"><p>Datos personales del usuario.</p></Page>
);
export const Security = () => (
  <Page title="Seguridad"><p>Contraseña y autenticación en dos pasos.</p></Page>
);

export const Help = () => (
  <Page title="Ayuda"><p>Preguntas frecuentes y contacto.</p></Page>
);
