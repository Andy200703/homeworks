// Nodo de un árbol N-ario: un valor y una lista de hijos
export class NaryNode {
  constructor(value) {
    this.value = value;
    this.children = [];
  }

  // addChild: agrega un nodo hijo y lo devuelve (permite encadenar)
  addChild(child) {
    this.children.push(child);
    return child;
  }

  isLeaf() {
    return this.children.length === 0;
  }
}

export class NaryTree {
  constructor(root) {
    this.root = root;
  }

  // DFS (profundidad): baja por cada rama antes de pasar a la siguiente
  dfs(node = this.root, result = []) {
    result.push(node.value);
    node.children.forEach((child) => this.dfs(child, result));
    return result;
  }

  // BFS (anchura): recorre nivel por nivel, de izquierda a derecha
  bfs() {
    const result = [];
    const queue = [this.root]; // usamos una cola, como en el Challenge 5
    while (queue.length > 0) {
      const node = queue.shift();
      result.push(node.value);
      queue.push(...node.children);
    }
    return result;
  }

  // Devuelve todos los valores como arreglo plano (útil para crear las rutas)
  toArray() {
    return this.dfs();
  }

  print() {
    console.log('DFS:', this.dfs().map((item) => item.title).join(' → '));
    console.log('BFS:', this.bfs().map((item) => item.title).join(' → '));
  }
}
