import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';

// ¿Algún descendiente de este nodo es la ruta actual?
function hasActiveChild(node, pathname) {
  return node.children.some(
    (child) => child.value.link === pathname || hasActiveChild(child, pathname)
  );
}

// Dibuja un nodo del árbol y, recursivamente, sus hijos
function MenuItem({ node }) {
  const { pathname } = useLocation();
  const { title, link } = node.value;
  const [open, setOpen] = useState(() => hasActiveChild(node, pathname));

  return (
    <li>
      <div className="menu-row">
        <NavLink to={link} end className="menu-link">
          {title}
        </NavLink>
        {!node.isLeaf() && (
          <button
            className="toggle"
            onClick={() => setOpen(!open)}
            aria-label={open ? 'Cerrar submenú' : 'Abrir submenú'}
          >
            {open ? '▾' : '▸'}
          </button>
        )}
      </div>

      {!node.isLeaf() && open && (
        <ul className="submenu">
          {node.children.map((child) => (
            <MenuItem key={child.value.link} node={child} />
          ))}
        </ul>
      )}
    </li>
  );
}

export default function Sidebar({ tree }) {
  // La raíz es solo el contenedor: se imprimen sus hijos
  return (
    <aside className="sidebar">
      <h2>Menú</h2>
      <ul>
        <li>
          <NavLink to="/" end className="menu-link">
            Inicio
          </NavLink>
        </li>
        {tree.root.children.map((child) => (
          <MenuItem key={child.value.link} node={child} />
        ))}
      </ul>
    </aside>
  );
}
