import { Trie } from "./Trie.js";
import { MaxHeap } from "./MaxHeap.js";

/**
 * RETO 12 - Smart search engine + Top results
 * - Los productos se guardan en un Trie
 * - Se busca por prefijo
 * - Un Max Heap devuelve los Top K más populares
 */
export class SearchEngine {
  constructor() {
    this.trie = new Trie();
  }

  /** insert("air max", 90) */
  insert(name, popularity) {
    return this.trie.insert(name, { name, popularity });
  }

  /** Productos que empiezan con el prefijo (sin ordenar por popularidad). */
  searchByPrefix(prefix) {
    return this.trie.suggest(prefix);
  }

  /**
   * searchTopK("air", 2) -> los 2 productos más populares que empiezan con "air".
   * 1) El Trie entrega los candidatos del prefijo.
   * 2) Se cargan en un Max Heap (heapify, O(n)) con la popularidad como clave.
   * 3) Se hacen k pops (O(k log n)).
   */
  searchTopK(prefix, k) {
    const candidates = this.searchByPrefix(prefix);
    const heap = new MaxHeap((p) => p.popularity).heapify(candidates);
    const result = [];
    while (result.length < k && !heap.isEmpty()) {
      const { name, popularity } = heap.pop();
      result.push({ name, popularity });
    }
    return result;
  }

  size() {
    return this.trie.size();
  }
}
