import { useMemo, useState } from "react";
import { SearchEngine } from "../structures/SearchEngine.js";

const seed = () => {
  const e = new SearchEngine();
  [
    ["air max", 90], ["air force", 95], ["air jordan", 85], ["adidas boost", 80],
    ["adidas superstar", 88], ["nike dunk", 92], ["puma suede", 70], ["new balance 550", 84],
  ].forEach(([n, p]) => e.insert(n, p));
  return e;
};

export default function Reto12() {
  const engine = useMemo(seed, []);
  const [, force] = useState(0);
  const [prefix, setPrefix] = useState("air");
  const [k, setK] = useState(2);
  const [form, setForm] = useState({ name: "", popularity: "" });

  const results = prefix.trim() ? engine.searchTopK(prefix, k) : [];
  const total = prefix.trim() ? engine.searchByPrefix(prefix).length : 0;

  const add = (e) => {
    e.preventDefault();
    if (!form.name.trim() || form.popularity === "") return;
    engine.insert(form.name.trim(), Number(form.popularity));
    setForm({ name: "", popularity: "" });
    force((n) => n + 1);
  };

  return (
    <div className="dashboard__grid">
      <section className="panel">
        <h2 className="panel__heading">Buscador inteligente · Top K</h2>
        <div className="row">
          <input className="grow input" placeholder="Prefijo…" value={prefix} onChange={(e) => setPrefix(e.target.value)} />
          <label className="row muted">Top&nbsp;
            <input className="input small" type="number" min="1" value={k}
                   onChange={(e) => setK(Math.max(1, Number(e.target.value) || 1))} />
          </label>
        </div>
        <p className="muted">
          <code>searchTopK("{prefix}", {k})</code> · {total} coincidencia(s) en el Trie
        </p>
        <ol className="ranking">
          {results.map((p, i) => (
            <li key={p.name} className="ranking__item">
              <span className={`ranking__position ${i < 3 ? `ranking__position--${i + 1}` : ""}`}>{i + 1}</span>
              <div className="ranking__info"><div className="ranking__song">{p.name}</div></div>
              <span className="ranking__plays">{p.popularity}</span>
            </li>
          ))}
          {prefix.trim() && results.length === 0 && <li className="muted">Sin resultados.</li>}
        </ol>
        <pre className="json">{JSON.stringify(results, null, 2)}</pre>
      </section>

      <section className="panel">
        <h2 className="panel__heading">Nuevo producto</h2>
        <form className="form" onSubmit={add}>
          <input placeholder="Nombre (ej. air zoom)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input type="number" min="0" placeholder="Popularidad" value={form.popularity}
                 onChange={(e) => setForm({ ...form, popularity: e.target.value })} />
          <button className="btn" type="submit">Insertar</button>
        </form>
        <p className="muted">Productos en el Trie: {engine.size()}</p>
      </section>
    </div>
  );
}
