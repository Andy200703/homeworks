import Reto12 from "./pages/Reto12.jsx";

export default function App() {
  return (
    <div className="dashboard">
      <header className="dashboard__header">
        <h1 className="dashboard__title">Reto 12 <span>· Smart search + Top K</span></h1>
      </header>
      <Reto12 />
    </div>
  );
}
