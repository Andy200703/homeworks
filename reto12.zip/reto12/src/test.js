import assert from "node:assert/strict";
import { SearchEngine } from "./structures/SearchEngine.js";

let passed = 0;
const test = (name, fn) => { fn(); passed++; console.log("  ok  -", name); };
const build = () => {
  const e = new SearchEngine();
  e.insert("air max", 90); e.insert("air force", 95);
  e.insert("air jordan", 85); e.insert("adidas boost", 80);
  return e;
};

console.log("Reto 12 - Trie + Heap");
test("ejemplo del enunciado: searchTopK('air', 2)", () =>
  assert.deepEqual(build().searchTopK("air", 2), [
    { name: "air force", popularity: 95 },
    { name: "air max", popularity: 90 },
  ]));
test("el prefijo filtra: 'ad' solo trae adidas", () =>
  assert.deepEqual(build().searchTopK("ad", 5).map((p) => p.name), ["adidas boost"]));
test("k mayor que los resultados devuelve todos", () =>
  assert.equal(build().searchTopK("air", 10).length, 3));
test("prefijo sin resultados", () =>
  assert.deepEqual(build().searchTopK("puma", 3), []));
test("prefijo vacío trae todo el catálogo ordenado", () =>
  assert.deepEqual(build().searchTopK("", 4).map((p) => p.popularity), [95, 90, 85, 80]));
console.log(`\n${passed} pruebas pasaron`);
