import { Graph } from "./Graph.js";

/**
 * RETO 11 - Grafo de amigos y ciudades (no dirigido)
 * - Cada persona es un nodo { name, age } y cada ciudad también { name }
 * - Cada persona está referenciada (conectada) a UNA ciudad
 * - También se pueden conectar amigos entre sí
 */
export class SocialGraph {
  constructor() {
    this.graph = new Graph();
    this.cityOf = new Map(); // persona -> ciudad (garantiza una sola ciudad)
  }

  addCity(name) {
    return this.graph.addNode(name, { type: "city", name });
  }

  /** Agrega una persona y la conecta a su ciudad (la crea si no existe). */
  addPerson(name, age, city) {
    if (this.graph.searchNode(name)) return false; // nombres únicos
    this.addCity(city);
    this.graph.addNode(name, { type: "person", name, age });
    this.graph.addEdge(name, city);
    this.cityOf.set(name, city);
    return true;
  }

  /** Conecta a dos personas como amigas. */
  addFriendship(a, b) {
    const isPerson = (n) => this.graph.searchNode(n)?.type === "person";
    if (!isPerson(a) || !isPerson(b)) return false;
    return this.graph.addEdge(a, b);
  }

  /** Lista de personas que viven en una ciudad (vecinos del nodo ciudad que son personas). */
  getPeopleInCity(city) {
    const node = this.graph.searchNode(city);
    if (!node || node.type !== "city") return [];
    return this.graph.printAdjacency(city).filter((n) => n.type === "person");
  }

  getCities() {
    return [...this.graph.nodes.values()].filter((n) => n.type === "city");
  }

  getPeople() {
    return [...this.graph.nodes.values()].filter((n) => n.type === "person");
  }

  /** Formato que pide react-d3-graph: { nodes: [{id}], links: [{source, target}] } */
  toD3Data() {
    const nodes = [...this.graph.nodes.values()].map((n) => ({
      id: n.id,
      type: n.type,
      color: n.type === "city" ? "#1db954" : "#3b82f6",
      size: n.type === "city" ? 700 : 350,
      symbolType: n.type === "city" ? "square" : "circle",
    }));
    const links = [];
    for (const [a, neighbors] of this.graph.adjacency)
      for (const b of neighbors) if (a < b) links.push({ source: a, target: b }); // 1 sola vez
    return { nodes, links };
  }
}
