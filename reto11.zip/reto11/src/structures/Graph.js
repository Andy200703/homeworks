/**
 * GRAFO NO DIRIGIDO - Canciones relacionadas
 * ------------------------------------------
 * Vértices = canciones. Aristas = "son similares".
 * Como es NO dirigido, si A se parece a B entonces B se parece a A, por eso
 * addEdge guarda la conexión en las dos listas de adyacencia.
 * Representación: lista de adyacencia (Map nodo -> Set de vecinos).
 */
export class Graph {
  constructor() {
    this.nodes = new Map();      // id -> datos del nodo
    this.adjacency = new Map();  // id -> Set de ids vecinos
  }

  /** addNode: agrega un nodo (canción) al grafo. */
  addNode(id, data = {}) {
    if (this.nodes.has(id)) return false;
    this.nodes.set(id, { id, ...data });
    this.adjacency.set(id, new Set());
    return true;
  }

  /** searchNode: retorna el nodo o null. */
  searchNode(id) {
    return this.nodes.get(id) ?? null;
  }

  /** addEdge: une dos nodos en AMBAS direcciones. */
  addEdge(a, b) {
    if (a === b || !this.nodes.has(a) || !this.nodes.has(b)) return false;
    this.adjacency.get(a).add(b);
    this.adjacency.get(b).add(a);
    return true;
  }

  /** printAdjacency: retorna los vecinos directos de un nodo. */
  printAdjacency(id) {
    if (!this.nodes.has(id)) return [];
    return [...this.adjacency.get(id)].map((n) => this.nodes.get(n));
  }

  /** removeNode: elimina el nodo y todas las aristas que lo tocan. */
  removeNode(id) {
    if (!this.nodes.has(id)) return false;
    for (const neighbor of this.adjacency.get(id)) {
      this.adjacency.get(neighbor).delete(id);
    }
    this.adjacency.delete(id);
    this.nodes.delete(id);
    return true;
  }

  isEmpty() {
    return this.nodes.size === 0;
  }

  /** print: imprime el contenido completo del grafo. */
  print() {
    let out = "";
    for (const [id, neighbors] of this.adjacency) {
      out += `${id} -> ${[...neighbors].join(", ") || "(sin conexiones)"}\n`;
    }
    return out;
  }

  /**
   * Recomendaciones: BFS desde una canción.
   * Nivel 1 = similares directas, nivel 2 = similares de las similares, etc.
   * @param {string} id        canción de partida
   * @param {number} maxDepth  qué tan lejos buscar
   */
  recommend(id, maxDepth = 1) {
    if (!this.nodes.has(id)) return [];
    const visited = new Set([id]);
    let frontier = [id];
    const result = [];

    for (let depth = 1; depth <= maxDepth; depth++) {
      const next = [];
      for (const current of frontier) {
        for (const neighbor of this.adjacency.get(current)) {
          if (visited.has(neighbor)) continue;
          visited.add(neighbor);
          next.push(neighbor);
          result.push({ ...this.nodes.get(neighbor), distance: depth });
        }
      }
      frontier = next;
    }
    return result;
  }
}
