import assert from "node:assert/strict";
import { SocialGraph } from "./structures/SocialGraph.js";

let passed = 0;
const test = (name, fn) => { fn(); passed++; console.log("  ok  -", name); };
const build = () => {
  const g = new SocialGraph();
  g.addPerson("Ana", 25, "Cali"); g.addPerson("Luis", 30, "Cali");
  g.addPerson("Marta", 28, "Bogotá"); g.addPerson("Pedro", 22, "Medellín");
  g.addFriendship("Ana", "Marta");
  return g;
};

console.log("Reto 11 - Grafo de amigos y ciudades");
test("personas que viven en una ciudad", () =>
  assert.deepEqual(build().getPeopleInCity("Cali").map((p) => p.name).sort(), ["Ana", "Luis"]));
test("la amistad NO cuenta como vivir en la ciudad", () =>
  assert.deepEqual(build().getPeopleInCity("Bogotá").map((p) => p.name), ["Marta"]));
test("cada persona tiene una sola ciudad", () => {
  const g = build();
  assert.equal(g.addPerson("Ana", 40, "Bogotá"), false);
  assert.equal(g.cityOf.get("Ana"), "Cali");
});
test("ciudad inexistente devuelve lista vacía", () =>
  assert.deepEqual(build().getPeopleInCity("Roma"), []));
test("formato react-d3-graph: aristas sin duplicar", () => {
  const { nodes, links } = build().toD3Data();
  assert.equal(nodes.length, 7);
  assert.equal(links.length, 5);
});
console.log(`\n${passed} pruebas pasaron`);
