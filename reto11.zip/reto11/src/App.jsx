import Reto11 from "./pages/Reto11.jsx";

export default function App() {
  return (
    <div className="dashboard">
      <header className="dashboard__header">
        <h1 className="dashboard__title">Reto 11 <span>· Grafo de amigos y ciudades</span></h1>
      </header>
      <Reto11 />
    </div>
  );
}
