import { useMemo, useState } from "react";
import { Graph } from "react-d3-graph";
import { SocialGraph } from "../structures/SocialGraph.js";

// Datos de ejemplo
const seed = () => {
  const g = new SocialGraph();
  [
    ["Ana", 25, "Cali"], ["Luis", 30, "Cali"], ["Sofía", 22, "Cali"],
    ["Marta", 28, "Bogotá"], ["Camilo", 35, "Bogotá"],
    ["Pedro", 27, "Medellín"], ["Laura", 31, "Medellín"],
  ].forEach(([n, a, c]) => g.addPerson(n, a, c));
  g.addFriendship("Ana", "Marta");
  g.addFriendship("Luis", "Pedro");
  g.addFriendship("Sofía", "Laura");
  return g;
};

const graphConfig = {
  width: 700,
  height: 480,
  directed: false,
  nodeHighlightBehavior: true,
  linkHighlightBehavior: true,
  node: { labelProperty: "id", fontSize: 13, highlightFontSize: 15, highlightStrokeColor: "#fff", fontColor: "#ddd" },
  link: { highlightColor: "#1db954" },
  d3: { gravity: -250, linkLength: 120 },
};

export default function Reto11() {
  const social = useMemo(seed, []);
  const [, force] = useState(0);
  const [selectedCity, setSelectedCity] = useState("Cali");
  const [form, setForm] = useState({ name: "", age: "", city: "" });
  const [friends, setFriends] = useState({ a: "", b: "" });
  const [msg, setMsg] = useState("");

  const data = social.toD3Data();
  const people = social.getPeopleInCity(selectedCity);
  const cities = social.getCities();
  const allPeople = social.getPeople();

  const addPerson = (e) => {
    e.preventDefault();
    const { name, age, city } = form;
    if (!name.trim() || !city.trim() || !age) return setMsg("Completa nombre, edad y ciudad");
    const ok = social.addPerson(name.trim(), Number(age), city.trim());
    setMsg(ok ? "Persona agregada ✔" : "Ya existe una persona con ese nombre");
    if (ok) { setForm({ name: "", age: "", city: "" }); setSelectedCity(city.trim()); force((n) => n + 1); }
  };

  const addFriend = (e) => {
    e.preventDefault();
    const ok = social.addFriendship(friends.a, friends.b);
    setMsg(ok ? "Amistad creada ✔" : "Elige dos personas distintas");
    if (ok) force((n) => n + 1);
  };

  return (
    <div className="dashboard__grid">
      <section className="panel">
        <h2 className="panel__heading">Grafo de amigos y ciudades</h2>
        <p className="muted legend"><i className="dot dot--city" /> ciudad <i className="dot dot--person" /> persona</p>
        {/* key fuerza a react-d3-graph a redibujar cuando cambia el grafo */}
        <Graph
          key={`${data.nodes.length}-${data.links.length}`}
          id="friends-cities"
          data={data}
          config={graphConfig}
          onClickNode={(id) => social.graph.searchNode(id)?.type === "city" && setSelectedCity(id)}
        />
      </section>

      <div className="stack">
        <section className="panel">
          <h2 className="panel__heading">Personas que viven en…</h2>
          <select className="input" value={selectedCity} onChange={(e) => setSelectedCity(e.target.value)}>
            {cities.map((c) => <option key={c.id}>{c.name}</option>)}
          </select>
          <ul className="plain">
            {people.map((p) => <li key={p.id}><b>{p.name}</b> <span className="muted">· {p.age} años</span></li>)}
            {people.length === 0 && <li className="muted">Nadie vive aquí.</li>}
          </ul>
          <small className="muted">Tip: también puedes hacer clic sobre una ciudad en el grafo.</small>
        </section>

        <section className="panel">
          <h2 className="panel__heading">Nueva persona</h2>
          <form className="form" onSubmit={addPerson}>
            <input placeholder="Nombre" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input type="number" min="0" placeholder="Edad" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} />
            <input list="cities" placeholder="Ciudad (existente o nueva)" value={form.city}
                   onChange={(e) => setForm({ ...form, city: e.target.value })} />
            <datalist id="cities">{cities.map((c) => <option key={c.id} value={c.name} />)}</datalist>
            <button className="btn" type="submit">Agregar</button>
          </form>
        </section>

        <section className="panel">
          <h2 className="panel__heading">Conectar amigos</h2>
          <form className="form" onSubmit={addFriend}>
            {["a", "b"].map((k) => (
              <select key={k} value={friends[k]} onChange={(e) => setFriends({ ...friends, [k]: e.target.value })}>
                <option value="">Persona {k.toUpperCase()}</option>
                {allPeople.map((p) => <option key={p.id}>{p.name}</option>)}
              </select>
            ))}
            <button className="btn" type="submit">Conectar</button>
          </form>
          {msg && <p className="form__msg">{msg}</p>}
        </section>
      </div>
    </div>
  );
}
