import { useCallback, useEffect, useState } from "react";
import { supabase } from "../lib/supabase.js";

/** Custom hook: CRUD de la tabla "tareas" + lista en vivo con Realtime. */
export function useTasks() {
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState("");

  const fetchTasks = useCallback(async () => {
    const { data, error } = await supabase
      .from("tareas")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) setError(error.message);
    else setTasks(data);
  }, []);

  useEffect(() => {
    fetchTasks();
    // Realtime: ante cualquier cambio (INSERT/UPDATE/DELETE) se recarga la lista.
    // El RLS también filtra los eventos: solo llegan los del usuario.
    const channel = supabase
      .channel("tareas-en-vivo")
      .on("postgres_changes", { event: "*", schema: "public", table: "tareas" }, fetchTasks)
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [fetchTasks]);

  // user_id se llena solo (default auth.uid())
  const add = async (titulo) => {
    const { error } = await supabase.from("tareas").insert({ titulo });
    if (error) setError(error.message);
  };
  const toggle = async (task) => {
    const { error } = await supabase.from("tareas").update({ completada: !task.completada }).eq("id", task.id);
    if (error) setError(error.message);
  };
  const rename = async (id, titulo) => {
    const { error } = await supabase.from("tareas").update({ titulo }).eq("id", id);
    if (error) setError(error.message);
  };
  const remove = async (id) => {
    const { error } = await supabase.from("tareas").delete().eq("id", id);
    if (error) setError(error.message);
  };

  return { tasks, error, add, toggle, rename, remove };
}
