import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase.js";
import { useAuth } from "../context/AuthContext.jsx";

// Storage: sube la imagen a avatars/<uid>/avatar.png y la muestra
export default function Avatar() {
  const { user } = useAuth();
  const path = `${user.id}/avatar.png`;
  const [url, setUrl] = useState("");
  const [msg, setMsg] = useState("");

  const load = () => {
    const { data } = supabase.storage.from("avatars").getPublicUrl(path);
    setUrl(`${data.publicUrl}?t=${Date.now()}`); // t= evita la caché al reemplazar
  };
  useEffect(load, [path]);

  const upload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setMsg("Subiendo…");
    const { error } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
    if (error) return setMsg(error.message);
    setMsg("Avatar actualizado ✔");
    load();
  };

  return (
    <div className="avatar">
      <img src={url} alt="avatar" onError={(e) => (e.currentTarget.style.visibility = "hidden")}
           onLoad={(e) => (e.currentTarget.style.visibility = "visible")} />
      <label className="btn btn--ghost">
        Cambiar foto
        <input type="file" accept="image/*" hidden onChange={upload} />
      </label>
      {msg && <small className="muted">{msg}</small>}
    </div>
  );
}
