import { Link, Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { isConfigured } from "../lib/supabase.js";

// Aviso cuando faltan las variables de entorno
function SetupNotice() {
  return (
    <section className="panel">
      <h2 className="panel__heading">Falta configurar Supabase</h2>
      <ol>
        <li>Crea el proyecto en supabase.com y ejecuta <code>supabase/setup.sql</code> en el SQL Editor.</li>
        <li>Copia <code>.env.example</code> a <code>.env</code> y pon tu <b>Project URL</b> y tu <b>publishable key</b>.</li>
        <li>Reinicia <code>npm run dev</code>.</li>
      </ol>
    </section>
  );
}

export function Reto10Layout() {
  if (!isConfigured) return <SetupNotice />;
  return <Outlet />;
}

// Ruta privada: sin sesión se redirige al login
export function PrivateRoute() {
  const { user, loading } = useAuth();
  if (loading) return <p className="muted">Cargando…</p>;
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}

export const AuthLinks = () => (
  <p className="muted"><Link to="/login">Login</Link> · <Link to="/registro">Registro</Link></p>
);
