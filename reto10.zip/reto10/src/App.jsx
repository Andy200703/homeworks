import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext.jsx";
import { Reto10Layout, PrivateRoute } from "./components/Reto10Layout.jsx";
import AuthPage from "./pages/AuthPage.jsx";
import Reto10Tareas from "./pages/Reto10Tareas.jsx";

export default function App() {
  return (
    <AuthProvider>
      <HashRouter>
        <div className="dashboard">
          <header className="dashboard__header">
            <h1 className="dashboard__title">Reto 10 <span>· Supabase</span></h1>
          </header>
          <Routes>
            <Route path="/" element={<Navigate to="/tareas" replace />} />
            <Route element={<Reto10Layout />}>
              <Route path="login" element={<AuthPage mode="login" />} />
              <Route path="registro" element={<AuthPage mode="register" />} />
              <Route element={<PrivateRoute />}>
                <Route path="tareas" element={<Reto10Tareas />} />
              </Route>
            </Route>
            <Route path="/*" element={<section className="panel"><h2>404 · Página no encontrada</h2></section>} />
          </Routes>
        </div>
      </HashRouter>
    </AuthProvider>
  );
}
