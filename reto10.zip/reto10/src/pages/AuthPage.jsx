import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

// Una sola página sirve para Login y Registro (prop mode)
export default function AuthPage({ mode }) {
  const isLogin = mode === "login";
  const { user, login, register } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  if (user) return <Navigate to="/tareas" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setMsg("");
    const { data, error } = await (isLogin ? login : register)(email, password);
    if (error) return setMsg(error.message);
    if (isLogin || data.session) navigate("/tareas", { replace: true });
    else setMsg("Cuenta creada. Revisa tu correo para confirmarla y luego inicia sesión.");
  };

  return (
    <section className="panel narrow">
      <h2 className="panel__heading">{isLogin ? "Iniciar sesión" : "Crear cuenta"}</h2>
      <form className="form" onSubmit={submit}>
        <input type="email" placeholder="Correo" value={email} required onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="Contraseña (mín. 6)" minLength={6} value={password} required
               onChange={(e) => setPassword(e.target.value)} />
        <button className="btn" type="submit">{isLogin ? "Entrar" : "Registrarme"}</button>
        {msg && <p className="form__msg">{msg}</p>}
      </form>
      <p className="muted">
        {isLogin ? <>¿No tienes cuenta? <Link to="/registro">Regístrate</Link></>
                 : <>¿Ya tienes cuenta? <Link to="/login">Inicia sesión</Link></>}
      </p>
    </section>
  );
}
