import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useTasks } from "../hooks/useTasks.js";
import Avatar from "../components/Avatar.jsx";

export default function Reto10Tareas() {
  const { user, logout } = useAuth();
  const { tasks, error, add, toggle, rename, remove } = useTasks();
  const [title, setTitle] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    add(title.trim());
    setTitle("");
  };

  return (
    <section className="panel">
      <div className="row">
        <Avatar />
        <div className="grow">
          <h2 className="panel__heading">Mis tareas (en vivo)</h2>
          <p className="muted">{user.email}</p>
        </div>
        <button className="btn btn--ghost" onClick={logout}>Cerrar sesión</button>
      </div>

      <form className="row" onSubmit={submit}>
        <input className="grow input" placeholder="Nueva tarea…" value={title} onChange={(e) => setTitle(e.target.value)} />
        <button className="btn" type="submit">Agregar</button>
      </form>
      {error && <p className="form__msg">⚠ {error}</p>}

      <ul className="tasks">
        {tasks.map((t) => (
          <li key={t.id} className={t.completada ? "tasks__item tasks__item--done" : "tasks__item"}>
            <input type="checkbox" checked={t.completada} onChange={() => toggle(t)} />
            <span className="grow">{t.titulo}</span>
            <button className="btn btn--ghost" onClick={() => {
              const n = window.prompt("Editar tarea", t.titulo);
              if (n && n.trim()) rename(t.id, n.trim());
            }}>✎</button>
            <button className="btn btn--ghost" onClick={() => remove(t.id)}>🗑</button>
          </li>
        ))}
        {tasks.length === 0 && <li className="muted">No tienes tareas todavía.</li>}
      </ul>
    </section>
  );
}
