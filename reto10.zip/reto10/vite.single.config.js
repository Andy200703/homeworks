import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";

export default defineConfig({
  css: { preprocessorOptions: { scss: { api: "modern-compiler" } } },
  plugins: [react(), viteSingleFile()],
  build: { outDir: "dist-single" },
});
