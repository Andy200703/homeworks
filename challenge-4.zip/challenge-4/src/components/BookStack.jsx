export default function BookStack({ stack, onPop }) {
  // toArray() va de la base al tope; se invierte para mostrar el tope arriba
  const books = stack.toArray().reverse();
  const top = stack.peek();

  return (
    <section className="card">
      <h2>Pila de libros ({stack.size()})</h2>

      {stack.isEmpty() ? (
        <p className="muted">La pila está vacía.</p>
      ) : (
        <>
          <p className="peek">
            <strong>Tope (peek):</strong> {top.name}
          </p>
          <ul className="stack">
            {books.map((book, index) => (
              <li key={book.isbn + index} className={index === 0 ? 'top' : ''}>
                <strong>{book.name}</strong>
                <span>ISBN: {book.isbn}</span>
                <span>Autor: {book.author}</span>
                <span>Editorial: {book.editorial}</span>
              </li>
            ))}
          </ul>
        </>
      )}

      <button className="secondary" onClick={onPop} disabled={stack.isEmpty()}>
        Sacar el tope (pop)
      </button>
    </section>
  );
}