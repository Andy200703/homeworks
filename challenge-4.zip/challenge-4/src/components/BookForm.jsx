import { useState } from 'react';

const EMPTY_BOOK = { name: '', isbn: '', author: '', editorial: '' };

export default function BookForm({ onAdd }) {
  const [book, setBook] = useState(EMPTY_BOOK);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setBook({ ...book, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const clean = Object.fromEntries(
      Object.entries(book).map(([key, value]) => [key, value.trim()])
    );
    if (Object.values(clean).some((value) => value === '')) {
      setError('Todos los campos son obligatorios.');
      return;
    }
    setError('');
    onAdd(clean);
    setBook(EMPTY_BOOK);
  };

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h2>Nuevo libro</h2>
      <label>
        Nombre
        <input name="name" value={book.name} onChange={handleChange} />
      </label>
      <label>
        ISBN
        <input name="isbn" value={book.isbn} onChange={handleChange} />
      </label>
      <label>
        Autor
        <input name="author" value={book.author} onChange={handleChange} />
      </label>
      <label>
        Editorial
        <input name="editorial" value={book.editorial} onChange={handleChange} />
      </label>
      {error && <p className="error">{error}</p>}
      <button type="submit">Agregar a la pila (push)</button>
    </form>
  );
}