import { useState } from 'react';
import BookForm from './components/bookForm';
import BookStack from './components/BookStack';
import { createInitialStack } from './data/mockBooks';

export default function App() {
  const [stack, setStack] = useState(createInitialStack);

  const handleAdd = (book) => {
    const next = stack.clone();
    next.push(book);
    next.print(); // imprime la pila en la consola
    setStack(next);
  };

  const handlePop = () => {
    const next = stack.clone();
    next.pop();
    setStack(next);
  };

  return (
    <main className="container">
      <h1>Challenge 04 · Pila de libros</h1>
      <div className="grid">
        <BookForm onAdd={handleAdd} />
        <BookStack stack={stack} onPop={handlePop} />
      </div>
    </main>
  );
}