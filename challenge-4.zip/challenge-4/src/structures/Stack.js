// Pila (LIFO): el último elemento en entrar es el primero en salir.
export class Stack {
  #items = [];

  // push: agrega un valor en el tope de la pila
  push(value) {
    this.#items.push(value);
    return this;
  }

  // pop: devuelve el último valor ingresado y lo elimina de la pila
  pop() {
    return this.#items.pop();
  }

  // peek: devuelve el último valor ingresado SIN eliminarlo
  peek() {
    return this.#items[this.#items.length - 1];
  }

  // isEmpty: true si la pila está vacía
  isEmpty() {
    return this.#items.length === 0;
  }

  // size: número de elementos en la pila
  size() {
    return this.#items.length;
  }

  // print: imprime el contenido de la pila (de la base al tope)
  print() {
    console.log(this.#items);
  }

  // Copia en arreglo (base -> tope), útil para renderizar en React
  toArray() {
    return [...this.#items];
  }

  // Copia de la pila: React necesita una referencia nueva para re-renderizar
  clone() {
    const copy = new Stack();
    this.#items.forEach((item) => copy.push(item));
    return copy;
  }
}