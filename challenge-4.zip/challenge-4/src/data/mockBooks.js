import { Stack } from '../structures/Stack';

// Crea la pila inicial con datos de prueba
export function createInitialStack() {
  const stack = new Stack();
  stack.push({
    name: 'Cien años de soledad',
    isbn: '978-0307474728',
    author: 'Gabriel García Márquez',
    editorial: 'Vintage Español',
  });
  stack.push({
    name: 'El coronel no tiene quien le escriba',
    isbn: '978-0060886165',
    author: 'Gabriel García Márquez',
    editorial: 'Harper Perennial',
  });
  stack.push({
    name: 'Clean Code',
    isbn: '978-0132350884',
    author: 'Robert C. Martin',
    editorial: 'Prentice Hall',
  });
  return stack;
}