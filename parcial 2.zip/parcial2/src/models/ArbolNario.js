export class Nodo {
  constructor(id, nombre, tipo, correoCreador) {
    this.id = id;
    this.nombre = nombre;
    this.tipo = tipo;
    this.correoCreador = correoCreador;
    this.hijos = [];
  }

  agregarHijo(nuevoNodo) {

    if (this.tipo === "archivo") {
      alert("Error: Un archivo no puede contener otros elementos.");
      return false;
    }
    this.hijos.push(nuevoNodo);
    return true;
  }
}

export class ArbolNario {
  constructor() {
    this.raiz = null;
  }


  agregarNodo(idPadre, nuevoNodo) {
    if (!this.raiz) {
      this.raiz = nuevoNodo;
      return true;
    }

    const padre = this.buscarDFS(this.raiz, idPadre);
    if (padre) {
      return padre.agregarHijo(nuevoNodo);
    }
    return false;
  }

  buscarDFS(nodoActual, idObjetivo) {
    if (nodoActual.id === idObjetivo) return nodoActual;
    for (let hijo of nodoActual.hijos) {
      const encontrado = this.buscarDFS(hijo, idObjetivo);
      if (encontrado) return encontrado;
    }
    return null;
  }
}