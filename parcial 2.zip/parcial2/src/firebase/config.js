
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAX6-Wo7FaliAoptiOqgDK_ABLOcXSWfx0",
  authDomain: "parcial-2-98f3f.firebaseapp.com",
  projectId: "parcial-2-98f3f",
  storageBucket: "parcial-2-98f3f.firebasestorage.app",
  messagingSenderId: "688169192870",
  appId: "1:688169192870:web:9fa9f7563ed11c3fdd9367",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);