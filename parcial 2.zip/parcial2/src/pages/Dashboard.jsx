import { useState, useEffect, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { db } from "../firebase/config";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { Nodo, ArbolNario } from "../models/ArbolNario";
import { TreeNode } from "../components/TreeNode";

export const Dashboard = () => {
  const { user, logout } = useContext(AuthContext);
  const [arbol, setArbol] = useState(new ArbolNario());
  const [triggerRender, setTriggerRender] = useState(0); // Para forzar re-render


  useEffect(() => {
    const fetchTree = async () => {
      const docRef = doc(db, "sistema_archivos", "raiz");
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const arbolBD = new ArbolNario();
        arbolBD.raiz = docSnap.data().raiz;
        setArbol(arbolBD);
      } else {
        const nuevoArbol = new ArbolNario();
        const nodoRaiz = new Nodo("root", "Raíz del Sistema", "carpeta", "sistema");
        nuevoArbol.agregarNodo(null, nodoRaiz);
        setArbol(nuevoArbol);
        await setDoc(docRef, { raiz: nuevoArbol.raiz });
      }
    };
    fetchTree();
  }, []);

  const handleAgregar = async (idPadre) => {
    const nombre = prompt("Nombre del nuevo elemento:");
    if (!nombre) return;
    const tipo = prompt("Escribe el tipo ('carpeta' o 'archivo'):").toLowerCase();
    
    if (tipo !== "carpeta" && tipo !== "archivo") {
      alert("Tipo inválido.");
      return;
    }

    const nuevoNodo = new Nodo(Date.now().toString(), nombre, tipo, user.email);
    

    const exito = arbol.agregarNodo(idPadre, nuevoNodo);
    
    if (exito) {
      const docRef = doc(db, "sistema_archivos", "raiz");
      await setDoc(docRef, { raiz: arbol.raiz });
      
      setTriggerRender(prev => prev + 1); 
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Gestor de Archivos</h2>
      <p>Usuario actual: {user.email} <button onClick={logout}>Salir</button></p>
      
      <div className="arbol-container">
        <TreeNode node={arbol.raiz} onAddClick={handleAgregar} />
      </div>
    </div>
  );
};