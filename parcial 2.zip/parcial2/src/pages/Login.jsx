import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase/config";

export const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  
  // Consumimos la función login que creamos en nuestro AuthContext
  const { login } = useContext(AuthContext);
  
  // Usamos useNavigate para redireccionar después de interactuar (React Router v6)
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      // Intentamos iniciar sesión con Firebase
      await login(email, password);
      // Si es exitoso, redirigimos a la ruta raíz (Dashboard)
      navigate("/", { replace: true }); 
    } catch (err) {
      setError("Error al iniciar sesión: Verifica tus credenciales.");
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      // Creamos un nuevo usuario en Firebase
      await createUserWithEmailAndPassword(auth, email, password);
      // Si es exitoso, Firebase auto-loguea al usuario y redirigimos
      navigate("/", { replace: true });
    } catch (err) {
      setError("Error al registrar: " + err.message);
    }
  };

  return (
    <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
      <div style={{ width: "300px", padding: "20px", border: "1px solid #ccc", borderRadius: "8px" }}>
        <h2>Acceso al Sistema</h2>
        
        <form>
          <div style={{ marginBottom: "15px" }}>
            <label style={{ display: "block", marginBottom: "5px" }}>Correo electrónico:</label>
            <input
              type="email"
              placeholder="usuario@correo.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={{ width: "100%", padding: "8px", boxSizing: "border-box" }}
              required
            />
          </div>

          <div style={{ marginBottom: "15px" }}>
            <label style={{ display: "block", marginBottom: "5px" }}>Contraseña:</label>
            <input
              type="password"
              placeholder="******"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{ width: "100%", padding: "8px", boxSizing: "border-box" }}
              required
            />
          </div>

          {error && <p style={{ color: "red", fontSize: "14px" }}>{error}</p>}

          <button 
            onClick={handleLogin} 
            style={{ width: "100%", padding: "10px", backgroundColor: "#3498db", color: "white", border: "none", borderRadius: "4px", marginBottom: "10px", cursor: "pointer" }}
          >
            Iniciar Sesión
          </button>
          
          <button 
            onClick={handleRegister} 
            type="button" 
            style={{ width: "100%", padding: "10px", backgroundColor: "#2ecc71", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}
          >
            Registrar Nuevo Usuario
          </button>
        </form>
      </div>
    </div>
  );
};