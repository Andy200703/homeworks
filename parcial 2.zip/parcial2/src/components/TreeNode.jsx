import "../styles/Tree.scss";

export const TreeNode = ({ node, onAddClick }) => {
  if (!node) return null;

  return (
    <div className="tree-node">
      <div className={`node-content ${node.tipo}`}>
        <span>{node.tipo === "carpeta" ? "📁" : "📄"} {node.nombre}</span>
        <span className="creator">({node.correoCreador})</span>
        
        {node.tipo === "carpeta" && (
          <button onClick={() => onAddClick(node.id)}>+</button>
        )}
      </div>

      {node.hijos && node.hijos.length > 0 && (
        <div className="children">
          {node.hijos.map((hijo) => (
            <TreeNode key={hijo.id} node={hijo} onAddClick={onAddClick} />
          ))}
        </div>
      )}
    </div>
  );
};