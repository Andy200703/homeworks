import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";

// Genera un único HTML autocontenido para abrir con doble clic
export default defineConfig({ css: { preprocessorOptions: { scss: { api: "modern-compiler" } } },
  plugins: [react(), viteSingleFile()], build: { outDir: "dist-single" } });
