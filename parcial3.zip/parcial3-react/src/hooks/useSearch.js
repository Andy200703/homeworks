import { useState } from "react";
import { useMusic } from "./useMusic.js";

/** Custom hook del buscador predictivo (usa el Trie). */
export function useSearch(limit = 6) {
  const { platform } = useMusic(); // useMusic re-renderiza al cambiar "version"
  const [query, setQuery] = useState("");
  const suggestions = query.trim() ? platform.suggest(query, limit) : [];
  const exists = query.trim() ? platform.exists(query) : false;
  return { query, setQuery, suggestions, exists };
}
