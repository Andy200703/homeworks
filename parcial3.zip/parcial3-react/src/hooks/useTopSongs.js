import { useEffect } from "react";
import { useMusic } from "./useMusic.js";

/** Custom hook del ranking (usa el Max Heap). */
export function useTopSongs(k = 5) {
  const { platform, version } = useMusic();
  const top = platform.top(k);

  // Igual que en la Práctica 01: mostrar en consola cuando cambia el ranking
  useEffect(() => {
    console.log(`Ranking actualizado. #1: ${top[0]?.title}`);
  }, [version]); // eslint-disable-line react-hooks/exhaustive-deps

  return top;
}
