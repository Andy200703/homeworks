import { useContext } from "react";
import { MusicContext } from "../context/MusicContext.jsx";

// Custom hook: acceso al contexto con validación
export function useMusic() {
  const ctx = useContext(MusicContext);
  if (!ctx) throw new Error("useMusic debe usarse dentro de <MusicProvider>");
  return ctx;
}
