import { useNavigate, useParams } from "react-router-dom";
import { useMusic } from "../hooks/useMusic.js";
import RelatedTags from "../components/RelatedTags.jsx";

// Ruta dinámica /song/:title  (URL segment -> useParams)
export default function SongDetail() {
  const { title } = useParams();
  const { platform, playSong } = useMusic();
  const navigate = useNavigate();
  const song = platform.getSong(decodeURIComponent(title));

  if (!song) return <section className="panel"><p>No existe esa canción.</p></section>;

  return (
    <section className="panel">
      <button className="btn btn--ghost" onClick={() => navigate(-1)}>← Volver</button>
      <h2 className="detail__title">{song.title}</h2>
      <p className="muted">{song.artist} · {song.plays.toLocaleString("es-CO")} reproducciones</p>
      <button className="btn" onClick={() => playSong(song.title)}>▶ Reproducir</button>

      <h3 className="panel__sub">Canciones relacionadas</h3>
      <RelatedTags
        songs={platform.recommend(song.title, 1)}
        onSelect={(t) => navigate(`/song/${encodeURIComponent(t)}`)}
      />
    </section>
  );
}
