import { useState } from "react";
import { useMusic } from "../hooks/useMusic.js";
import GraphView from "../components/GraphView.jsx";
import RelatedTags from "../components/RelatedTags.jsx";

export default function GraphPage() {
  const { platform, relateSongs } = useMusic();
  const titles = [...platform.graph.nodes.keys()].sort();
  const [selected, setSelected] = useState(null);
  const [a, setA] = useState("");
  const [b, setB] = useState("");

  return (
    <div className="dashboard__grid">
      <section className="panel">
        <h2 className="panel__heading">Grafo de canciones relacionadas</h2>
        <GraphView graph={platform.graph} selected={selected} onSelect={setSelected} />
      </section>
      <div className="stack">
        <section className="panel">
          <h2 className="panel__heading">Recomendaciones</h2>
          {selected ? (
            <>
              <p><strong>{selected}</strong></p>
              <RelatedTags songs={platform.recommend(selected, 2)} onSelect={setSelected} />
            </>
          ) : <p className="muted">Haz clic en un nodo del grafo.</p>}
        </section>
        <section className="panel">
          <h2 className="panel__heading">Relacionar dos canciones</h2>
          <form className="form" onSubmit={(e) => { e.preventDefault(); relateSongs(a, b); }}>
            <select value={a} onChange={(e) => setA(e.target.value)}>
              <option value="">Canción A</option>
              {titles.map((t) => <option key={t}>{t}</option>)}
            </select>
            <select value={b} onChange={(e) => setB(e.target.value)}>
              <option value="">Canción B</option>
              {titles.map((t) => <option key={t}>{t}</option>)}
            </select>
            <button className="btn" type="submit">Conectar</button>
          </form>
        </section>
      </div>
    </div>
  );
}
