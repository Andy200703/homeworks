import { Link } from "react-router-dom";

// Ruta /* -> página 404
export default function NotFound() {
  return (
    <section className="panel">
      <h2>404 · Página no encontrada</h2>
      <Link className="btn" to="/">Ir al inicio</Link>
    </section>
  );
}
