import { useNavigate } from "react-router-dom";
import { useMusic } from "../hooks/useMusic.js";
import { useTopSongs } from "../hooks/useTopSongs.js";
import SearchBox from "../components/SearchBox.jsx";
import RankingList from "../components/RankingList.jsx";
import SongForm from "../components/SongForm.jsx";
import RelatedTags from "../components/RelatedTags.jsx";

export default function Dashboard() {
  const { platform, addSong, playSong } = useMusic();
  const navigate = useNavigate();
  const top = useTopSongs(5);
  const goTo = (title) => navigate(`/song/${encodeURIComponent(title)}`);

  return (
    <div className="dashboard__grid">
      <section className="panel">
        <h2 className="panel__heading">Top 5 más escuchadas · Max Heap</h2>
        <RankingList songs={top} onPlay={playSong} onOpen={goTo} />
        {top[0] && (
          <>
            <h3 className="panel__sub">Similares a “{top[0].title}”</h3>
            <RelatedTags songs={platform.recommend(top[0].title, 2)} onSelect={goTo} />
          </>
        )}
      </section>

      <div className="stack">
        <section className="panel">
          <h2 className="panel__heading">Buscador · Trie</h2>
          <SearchBox onSelect={goTo} />
        </section>
        <section className="panel">
          <h2 className="panel__heading">Nueva canción</h2>
          <SongForm onAdd={addSong} />
        </section>
      </div>
    </div>
  );
}
