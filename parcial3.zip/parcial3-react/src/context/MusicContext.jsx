import { createContext, useCallback, useRef, useState } from "react";
import { buildSamplePlatform } from "../sampleData.js";

// 1) Crear el contexto
export const MusicContext = createContext(null);

// 2) Provider: la plataforma (Trie + Heap + Grafo) vive en un ref y
//    "version" fuerza el re-render cuando las estructuras cambian.
export function MusicProvider({ children }) {
  const platform = useRef(buildSamplePlatform());
  const [version, setVersion] = useState(0);
  const refresh = () => setVersion((v) => v + 1);

  const addSong = useCallback((title, artist, plays) => {
    const ok = platform.current.addSong(title, artist, plays);
    if (ok) refresh();
    return ok;
  }, []);

  const playSong = useCallback((title) => {
    if (platform.current.play(title)) refresh();
  }, []);

  const relateSongs = useCallback((a, b) => {
    const ok = platform.current.relate(a, b);
    if (ok) refresh();
    return ok;
  }, []);

  const value = { platform: platform.current, version, addSong, playSong, relateSongs };
  return <MusicContext.Provider value={value}>{children}</MusicContext.Provider>;
}
