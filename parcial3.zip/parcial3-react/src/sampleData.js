import { MusicPlatform } from "./MusicPlatform.js";

export function buildSamplePlatform() {
  const p = new MusicPlatform();

  const songs = [
    ["Despacito", "Luis Fonsi", 8200],
    ["Dákiti", "Bad Bunny", 6100],
    ["Danza Kuduro", "Don Omar", 4300],
    ["Darte un Beso", "Prince Royce", 2900],
    ["Hawái", "Maluma", 5400],
    ["Hasta la Raíz", "Natalia Lafourcade", 3100],
    ["Ojitos Lindos", "Bad Bunny", 7200],
    ["Tití Me Preguntó", "Bad Bunny", 6900],
    ["La Bachata", "Manuel Turizo", 6400],
    ["Felices los 4", "Maluma", 5800],
    ["Shakira: Bzrp Session 53", "Shakira", 9100],
    ["Waka Waka", "Shakira", 7700],
    ["Hips Don't Lie", "Shakira", 7000],
    ["Bailando", "Enrique Iglesias", 4800],
  ];
  songs.forEach(([t, a, n]) => p.addSong(t, a, n));

  [
    ["Despacito", "Bailando"],
    ["Despacito", "Danza Kuduro"],
    ["Despacito", "La Bachata"],
    ["Dákiti", "Ojitos Lindos"],
    ["Dákiti", "Tití Me Preguntó"],
    ["Ojitos Lindos", "Tití Me Preguntó"],
    ["Hawái", "Felices los 4"],
    ["Waka Waka", "Hips Don't Lie"],
    ["Waka Waka", "Shakira: Bzrp Session 53"],
    ["Danza Kuduro", "Bailando"],
    ["La Bachata", "Darte un Beso"],
  ].forEach(([a, b]) => p.relate(a, b));

  return p;
}
