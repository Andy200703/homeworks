import assert from "node:assert/strict";
import { Trie } from "./structures/Trie.js";
import { MaxHeap } from "./structures/MaxHeap.js";
import { Graph } from "./structures/Graph.js";
import { buildSamplePlatform } from "./sampleData.js";

let passed = 0;
const test = (name, fn) => { fn(); passed++; console.log("  ok  -", name); };

console.log("Trie");
test("insert + search", () => {
  const t = new Trie();
  t.insert("Hello", { title: "Hello" }); t.insert("Help", { title: "Help" });
  assert.equal(t.search("hello"), true);
  assert.equal(t.search("Help"), true);
});
test("un prefijo NO es una canción", () => {
  const t = new Trie(); t.insert("Hello", { title: "Hello" });
  assert.equal(t.search("Hel"), false);
  assert.equal(t.startsWith("Hel"), true);
});
test("sugerencias por prefijo (ignora tildes y mayúsculas)", () => {
  const t = new Trie();
  ["Dákiti", "Danza", "Despacito"].forEach((s) => t.insert(s, { title: s }));
  assert.deepEqual(t.suggest("DA").map((s) => s.title), ["Dákiti", "Danza"]);
  assert.deepEqual(t.suggest("x"), []);
});
test("límite de sugerencias", () => {
  const t = new Trie();
  ["a1", "a2", "a3"].forEach((s) => t.insert(s, { title: s }));
  assert.equal(t.suggest("a", 2).length, 2);
});

console.log("MaxHeap");
test("pop devuelve en orden descendente", () => {
  const h = new MaxHeap();
  [5, 1, 9, 3, 7, 2, 8].forEach((n) => h.push(n));
  const out = []; while (!h.isEmpty()) out.push(h.pop());
  assert.deepEqual(out, [9, 8, 7, 5, 3, 2, 1]);
});
test("peek y heapify", () => {
  const h = new MaxHeap().heapify([3, 10, 4, 1, 12]);
  assert.equal(h.peek(), 12);
  assert.equal(h.size(), 5);
});
test("topK no destruye el heap", () => {
  const h = new MaxHeap((s) => s.n);
  [{ n: 1 }, { n: 5 }, { n: 3 }].forEach((x) => h.push(x));
  assert.deepEqual(h.topK(2).map((x) => x.n), [5, 3]);
  assert.equal(h.size(), 3);
});

console.log("Graph");
test("aristas no dirigidas", () => {
  const g = new Graph(); g.addNode("A"); g.addNode("B");
  g.addEdge("A", "B");
  assert.deepEqual(g.printAdjacency("A").map((n) => n.id), ["B"]);
  assert.deepEqual(g.printAdjacency("B").map((n) => n.id), ["A"]);
});
test("removeNode limpia aristas", () => {
  const g = new Graph(); ["A", "B", "C"].forEach((n) => g.addNode(n));
  g.addEdge("A", "B"); g.addEdge("B", "C");
  g.removeNode("B");
  assert.equal(g.printAdjacency("A").length, 0);
  assert.equal(g.searchNode("B"), null);
});
test("no permite aristas a nodos inexistentes ni bucles", () => {
  const g = new Graph(); g.addNode("A");
  assert.equal(g.addEdge("A", "Z"), false);
  assert.equal(g.addEdge("A", "A"), false);
});

console.log("Plataforma");
test("integración Trie + Heap + Grafo", () => {
  const p = buildSamplePlatform();
  assert.equal(p.exists("Despacito"), true);
  assert.equal(p.top(1)[0].title, "Shakira: Bzrp Session 53");
  assert.ok(p.recommend("Despacito").some((s) => s.title === "Bailando"));
  assert.ok(p.recommend("Bailando").some((s) => s.title === "Despacito"));
});
test("play() reordena el ranking", () => {
  const p = buildSamplePlatform();
  for (let i = 0; i < 1000; i++) p.play("Despacito"); // 8200 -> 9200 > 9100
  assert.equal(p.top(1)[0].title, "Despacito");
  assert.equal(p.getSong("Despacito").plays, 9200);
});
test("no duplica canciones", () => {
  const p = buildSamplePlatform();
  assert.equal(p.addSong("despacito", "X", 1), false);
});

console.log(`\n${passed} pruebas pasaron`);
