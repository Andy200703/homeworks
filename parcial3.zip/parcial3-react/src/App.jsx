import { HashRouter, NavLink, Route, Routes } from "react-router-dom";
import { MusicProvider } from "./context/MusicContext.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import GraphPage from "./pages/GraphPage.jsx";
import SongDetail from "./pages/SongDetail.jsx";
import NotFound from "./pages/NotFound.jsx";

export default function App() {
  return (
    <MusicProvider>
      <HashRouter>
        <div className="dashboard">
          <header className="dashboard__header">
            <h1 className="dashboard__title">Mini <span>Spotify</span> educativo</h1>
            <nav className="nav">
              <NavLink to="/" end>Dashboard</NavLink>
              <NavLink to="/grafo">Grafo</NavLink>
            </nav>
          </header>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/grafo" element={<GraphPage />} />
            <Route path="/song/:title" element={<SongDetail />} />
            <Route path="/*" element={<NotFound />} />
          </Routes>
        </div>
      </HashRouter>
    </MusicProvider>
  );
}
