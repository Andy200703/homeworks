import { Trie } from "./structures/Trie.js";
import { MaxHeap } from "./structures/MaxHeap.js";
import { Graph } from "./structures/Graph.js";

/**
 * Plataforma que integra las tres estructuras:
 *  - Trie     -> buscar / autocompletar títulos
 *  - MaxHeap  -> ranking por reproducciones
 *  - Graph    -> canciones relacionadas (no dirigido)
 */
export class MusicPlatform {
  constructor() {
    this.trie = new Trie();
    this.ranking = new MaxHeap((song) => song.plays);
    this.graph = new Graph();
    this.songs = new Map(); // título -> objeto song compartido por las 3 estructuras
  }

  addSong(title, artist, plays = 0) {
    if (this.trie.search(title)) return false; // evita duplicados
    const song = { title, artist, plays };
    this.songs.set(title, song);
    this.trie.insert(title, song);
    this.ranking.push(song);
    this.graph.addNode(title, { title, artist });
    return true;
  }

  exists(title) {
    return this.trie.search(title);
  }

  getSong(title) {
    return this.songs.get(title) ?? null;
  }

  suggest(prefix, limit = 5) {
    return this.trie.suggest(prefix, limit);
  }

  /** Suma una reproducción y reordena el heap. */
  play(title) {
    const song = this.songs.get(title);
    if (!song) return false;
    song.plays++;
    this.ranking.heapify(this.ranking.items); // O(n), restaura la propiedad de heap
    return true;
  }

  /** TOP K canciones más escuchadas. */
  top(k = 5) {
    return this.ranking.topK(k);
  }

  /** Marca dos canciones como similares (relación en ambos sentidos). */
  relate(titleA, titleB) {
    return this.graph.addEdge(titleA, titleB);
  }

  recommend(title, depth = 1) {
    return this.graph.recommend(title, depth).map((n) => ({ ...n, ...this.songs.get(n.id) }));
  }
}
