import { useState } from "react";

// Formulario para insertar canciones (Trie + Heap + Grafo a la vez)
export default function SongForm({ onAdd }) {
  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [plays, setPlays] = useState(0);
  const [msg, setMsg] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim() || !artist.trim()) return setMsg("Completa título y artista");
    const ok = onAdd(title.trim(), artist.trim(), Number(plays) || 0);
    setMsg(ok ? "Canción agregada ✔" : "Esa canción ya existe");
    if (ok) { setTitle(""); setArtist(""); setPlays(0); }
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      <input placeholder="Título" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input placeholder="Artista" value={artist} onChange={(e) => setArtist(e.target.value)} />
      <input type="number" min="0" placeholder="Reproducciones" value={plays}
             onChange={(e) => setPlays(e.target.value)} />
      <button className="btn" type="submit">Agregar</button>
      {msg && <p className="form__msg">{msg}</p>}
    </form>
  );
}
