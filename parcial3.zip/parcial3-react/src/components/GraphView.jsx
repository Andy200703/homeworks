// Dibujo del grafo no dirigido en SVG (nodos en círculo, aristas = líneas)
export default function GraphView({ graph, selected, onSelect }) {
  const ids = [...graph.nodes.keys()];
  const size = 520, c = size / 2, r = size / 2 - 70;
  const pos = new Map(ids.map((id, i) => {
    const a = (2 * Math.PI * i) / ids.length - Math.PI / 2;
    return [id, { x: c + r * Math.cos(a), y: c + r * Math.sin(a) }];
  }));

  // Como es no dirigido, cada arista se dibuja una sola vez (a < b)
  const edges = [];
  for (const [a, neighbors] of graph.adjacency)
    for (const b of neighbors) if (a < b) edges.push([a, b]);

  const near = selected ? graph.adjacency.get(selected) : null;

  return (
    <svg className="graph" viewBox={`0 0 ${size} ${size}`}>
      {edges.map(([a, b]) => {
        const hot = selected && (a === selected || b === selected);
        return (
          <line key={a + b} x1={pos.get(a).x} y1={pos.get(a).y} x2={pos.get(b).x} y2={pos.get(b).y}
                className={hot ? "graph__edge graph__edge--hot" : "graph__edge"} />
        );
      })}
      {ids.map((id) => {
        const { x, y } = pos.get(id);
        const cls = id === selected ? "graph__node graph__node--selected"
          : near?.has(id) ? "graph__node graph__node--near" : "graph__node";
        return (
          <g key={id} className={cls} onClick={() => onSelect(id)}>
            <circle cx={x} cy={y} r="9" />
            <text x={x} y={y - 15} textAnchor="middle">{id.length > 16 ? id.slice(0, 15) + "…" : id}</text>
          </g>
        );
      })}
    </svg>
  );
}
