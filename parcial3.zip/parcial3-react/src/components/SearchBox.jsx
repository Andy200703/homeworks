import { useSearch } from "../hooks/useSearch.js";

// Buscador predictivo (Trie). El padre decide qué pasa al elegir (prop onSelect)
export default function SearchBox({ onSelect }) {
  const { query, setQuery, suggestions, exists } = useSearch();

  return (
    <div className="search">
      <input
        className="search__input"
        placeholder="Busca una canción…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      {query.trim() && (
        <p className="search__status">
          {exists ? "✔ La canción existe" : `${suggestions.length} sugerencia(s) para "${query}"`}
        </p>
      )}
      <ul className="search__suggestions">
        {suggestions.map((s) => (
          <li key={s.title} onClick={() => onSelect(s.title)}>
            {s.title}
            <small>{s.artist}</small>
          </li>
        ))}
      </ul>
    </div>
  );
}
