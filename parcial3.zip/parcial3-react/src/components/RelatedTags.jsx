// Muestra canciones relacionadas (vecinos en el grafo)
export default function RelatedTags({ songs, onSelect }) {
  if (songs.length === 0) return <p className="muted">Sin canciones relacionadas.</p>;
  return (
    <div>
      {songs.map((s) => (
        <button key={s.title} className="tag" onClick={() => onSelect(s.title)}>
          {s.title}
          {s.distance > 1 && <small> · nivel {s.distance}</small>}
        </button>
      ))}
    </div>
  );
}
