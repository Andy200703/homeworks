// Lista del TOP (Max Heap). Recibe los datos y callbacks por props.
export default function RankingList({ songs, onPlay, onOpen }) {
  return (
    <ol className="ranking">
      {songs.map((s, i) => (
        <li key={s.title} className="ranking__item">
          <span className={`ranking__position ${i < 3 ? `ranking__position--${i + 1}` : ""}`}>
            {i + 1}
          </span>
          <div className="ranking__info" onClick={() => onOpen(s.title)}>
            <div className="ranking__song">{s.title}</div>
            <div className="ranking__artist">{s.artist}</div>
          </div>
          <span className="ranking__plays">{s.plays.toLocaleString("es-CO")}</span>
          <button className="btn btn--ghost" onClick={() => onPlay(s.title)} title="Reproducir">
            ▶
          </button>
        </li>
      ))}
    </ol>
  );
}
