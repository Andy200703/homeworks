/**
 * MAX HEAP - Ranking de canciones más escuchadas
 * ----------------------------------------------
 * Árbol binario completo guardado en un arreglo.
 * Propiedad: el padre es siempre >= que sus hijos, así que la canción más
 * escuchada está siempre en la posición 0.
 *
 * Índices:  padre(i) = floor((i-1)/2)   izq(i) = 2i+1   der(i) = 2i+2
 */
export class MaxHeap {
  /**
   * @param {(item) => number} keyFn  función que extrae la clave de comparación
   */
  constructor(keyFn = (item) => item) {
    this.items = [];
    this.keyFn = keyFn;
  }

  // ---------- helpers ----------
  #parent = (i) => Math.floor((i - 1) / 2);
  #left = (i) => 2 * i + 1;
  #right = (i) => 2 * i + 2;
  #key = (i) => this.keyFn(this.items[i]);

  swap(i, j) {
    [this.items[i], this.items[j]] = [this.items[j], this.items[i]];
  }

  size() {
    return this.items.length;
  }

  isEmpty() {
    return this.items.length === 0;
  }

  toArray() {
    return [...this.items];
  }

  // ---------- operaciones principales ----------

  /** push: inserta al final y sube con percolateUp. O(log n) */
  push(item) {
    this.items.push(item);
    this.percolateUp(this.items.length - 1);
  }

  /** peek: consulta el máximo sin sacarlo. O(1) */
  peek() {
    return this.items[0] ?? null;
  }

  /** pop: saca el máximo, mueve el último a la raíz y baja con percolateDown. O(log n) */
  pop() {
    if (this.isEmpty()) return null;
    const max = this.items[0];
    const last = this.items.pop();
    if (!this.isEmpty()) {
      this.items[0] = last;
      this.percolateDown(0);
    }
    return max;
  }

  /** percolateUp: mientras el nodo sea mayor que su padre, intercambiarlos. */
  percolateUp(index) {
    let i = index;
    while (i > 0 && this.#key(i) > this.#key(this.#parent(i))) {
      this.swap(i, this.#parent(i));
      i = this.#parent(i);
    }
  }

  /** percolateDown: intercambiar con el hijo mayor mientras algún hijo sea mayor. */
  percolateDown(index) {
    let i = index;
    const n = this.items.length;
    while (true) {
      let largest = i;
      const l = this.#left(i);
      const r = this.#right(i);
      if (l < n && this.#key(l) > this.#key(largest)) largest = l;
      if (r < n && this.#key(r) > this.#key(largest)) largest = r;
      if (largest === i) break;
      this.swap(i, largest);
      i = largest;
    }
  }

  /** heapify: convierte un arreglo desordenado en heap en O(n). */
  heapify(array) {
    this.items = [...array];
    for (let i = Math.floor(this.items.length / 2) - 1; i >= 0; i--) {
      this.percolateDown(i);
    }
    return this;
  }

  /**
   * TOP K: devuelve las k canciones más escuchadas SIN destruir el heap
   * (se trabaja sobre una copia).
   */
  topK(k) {
    const copy = new MaxHeap(this.keyFn);
    copy.items = [...this.items];
    const top = [];
    while (top.length < k && !copy.isEmpty()) top.push(copy.pop());
    return top;
  }
}
