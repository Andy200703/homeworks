/**
 * TRIE - Buscador predictivo de canciones
 * ---------------------------------------
 * La información está en el camino, no en los nodos: cada arista es una letra.
 * La raíz es un nodo vacío (no representa ningún carácter).
 */

/** Normaliza texto: minúsculas, sin tildes y sin espacios extremos. */
export const normalize = (text) =>
  text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();

class TrieNode {
  constructor(value = null) {
    this.value = value;          // letra que representa este nodo
    this.children = new Map();   // letra -> TrieNode
    this.isEndOfWord = false;    // true si aquí termina un título completo
    this.data = null;            // información de la canción (solo si isEndOfWord)
  }
}

export class Trie {
  constructor() {
    this.root = new TrieNode(); // raíz nula
    this.count = 0;
  }

  /**
   * Inserta una canción. Recorre letra por letra creando nodos si no existen
   * y marca el último nodo con isEndOfWord = true.
   * @param {string} title  título de la canción
   * @param {object} data   datos asociados (artista, reproducciones, etc.)
   */
  insert(title, data = {}) {
    const word = normalize(title);
    if (!word) return false;

    let node = this.root;
    for (const letter of word) {
      if (!node.children.has(letter)) {
        node.children.set(letter, new TrieNode(letter));
      }
      node = node.children.get(letter);
    }
    if (!node.isEndOfWord) this.count++;
    node.isEndOfWord = true;
    node.data = data; // misma referencia que usa el heap (el título original va dentro de data)
    return true;
  }

  /** Devuelve el nodo al que se llega siguiendo un prefijo, o null si no existe. */
  #findNode(text) {
    let node = this.root;
    for (const letter of normalize(text)) {
      node = node.children.get(letter);
      if (!node) return null;
    }
    return node;
  }

  /**
   * Busca si una canción EXISTE (palabra completa).
   * Un prefijo no basta: el último nodo debe tener isEndOfWord = true.
   */
  search(title) {
    const node = this.#findNode(title);
    return node !== null && node.isEndOfWord;
  }

  /** Devuelve los datos de una canción exacta o null. */
  get(title) {
    const node = this.#findNode(title);
    return node && node.isEndOfWord ? node.data : null;
  }

  /** ¿Existe algún título que empiece con este prefijo? */
  startsWith(prefix) {
    return this.#findNode(prefix) !== null;
  }

  /**
   * Sugerencias por prefijo (autocompletar).
   * Se llega al nodo del prefijo y se hace un DFS recolectando todas las
   * canciones que terminan por debajo de él.
   * @param {string} prefix
   * @param {number} limit  máximo de sugerencias (Infinity = todas)
   * @returns {object[]} datos de las canciones, en orden alfabético
   */
  suggest(prefix, limit = Infinity) {
    const start = this.#findNode(prefix);
    if (!start) return [];

    const results = [];
    const dfs = (node) => {
      if (results.length >= limit) return;
      if (node.isEndOfWord) results.push(node.data);
      const letters = [...node.children.keys()].sort();
      for (const letter of letters) dfs(node.children.get(letter));
    };
    dfs(start);
    return results;
  }

  size() {
    return this.count;
  }
}
