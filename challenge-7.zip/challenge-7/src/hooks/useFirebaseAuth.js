import { useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { auth } from '../firebase/config';

// Convierte los códigos de error de Firebase en mensajes entendibles
const ERROR_MESSAGES = {
  'auth/invalid-credential': 'Correo o contraseña incorrectos.',
  'auth/invalid-email': 'El correo no es válido.',
  'auth/user-not-found': 'No existe una cuenta con ese correo.',
  'auth/wrong-password': 'Correo o contraseña incorrectos.',
  'auth/email-already-in-use': 'Ya existe una cuenta con ese correo.',
  'auth/weak-password': 'La contraseña debe tener al menos 6 caracteres.',
  'auth/too-many-requests': 'Demasiados intentos. Intenta más tarde.',
  'auth/network-request-failed': 'Error de red. Revisa tu conexión.',
};

function toFriendlyError(error) {
  return new Error(ERROR_MESSAGES[error.code] ?? 'Ocurrió un error inesperado.');
}

// Solo guardamos los datos que necesitamos del usuario de Firebase
function toPlainUser(firebaseUser) {
  if (!firebaseUser) return null;
  const { uid, email, displayName } = firebaseUser;
  return { uid, email, displayName };
}

// Custom hook: toda la lógica de Firebase Authentication
export function useFirebaseAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // true mientras Firebase recupera la sesión

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(toPlainUser(firebaseUser));
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const login = async (email, password) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      throw toFriendlyError(error);
    }
  };

  const register = async (name, email, password) => {
    try {
      const credential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(credential.user, { displayName: name });
      setUser(toPlainUser(auth.currentUser)); // refresca el nombre en pantalla
    } catch (error) {
      throw toFriendlyError(error);
    }
  };

  const logout = () => signOut(auth);

  return { user, loading, login, register, logout };
}
