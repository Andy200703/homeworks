import { useContext } from 'react';
import { TasksContext } from '../context/TasksContext';

export function useTasks() {
  const context = useContext(TasksContext);
  if (context === null) {
    throw new Error('useTasks debe usarse dentro de un <TasksProvider>');
  }
  return context;
}
