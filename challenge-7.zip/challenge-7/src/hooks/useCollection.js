import { useCallback } from 'react';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  query,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db } from '../firebase/config';

// Custom hook: CRUD básico para cualquier colección de Firestore
export function useCollection(collectionName) {
  // getAll: filters = [["campo", "==", valor], ...]
  const getAll = useCallback(
    async (filters = []) => {
      const conditions = filters.map(([field, operator, value]) =>
        where(field, operator, value)
      );
      const q = query(collection(db, collectionName), ...conditions);
      const snapshot = await getDocs(q);
      return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    },
    [collectionName]
  );

  // add: crea un documento y devuelve el id generado por Firebase
  const add = useCallback(
    async (data) => {
      const docRef = await addDoc(collection(db, collectionName), data);
      return docRef.id;
    },
    [collectionName]
  );

  // update: usa el id del documento (generado por Firebase)
  const update = useCallback(
    async (id, data) => {
      await updateDoc(doc(db, collectionName, id), data);
    },
    [collectionName]
  );

  // remove: elimina el documento con ese id
  const remove = useCallback(
    async (id) => {
      await deleteDoc(doc(db, collectionName, id));
    },
    [collectionName]
  );

  return { getAll, add, update, remove };
}
