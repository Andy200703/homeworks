import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <main className="auth-page text-center">
      <h1>404</h1>
      <p className="text-muted">La página que buscas no existe.</p>
      <Link className="btn btn-primary" to="/tasks">
        Ir a mis tareas
      </Link>
    </main>
  );
}
