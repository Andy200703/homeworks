import TaskForm from '../components/TaskForm';
import TaskItem from '../components/TaskItem';
import { useTasks } from '../hooks/useTasks';

export default function Tasks() {
  const { tasks, loading, error } = useTasks();
  const doneCount = tasks.filter((t) => t.done).length;

  return (
    <main className="container tasks-page">
      <TaskForm />

      <div className="d-flex justify-content-between align-items-center mb-2">
        <h2 className="h5 mb-0">Tus tareas</h2>
        <span className="badge text-bg-secondary">
          {doneCount} de {tasks.length} hechas
        </span>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      {loading ? (
        <div className="d-flex justify-content-center py-4">
          <div className="spinner-border text-primary" role="status" />
        </div>
      ) : tasks.length === 0 ? (
        <p className="text-muted">Aún no tienes tareas. ¡Crea la primera!</p>
      ) : (
        <ul className="list-group app-card">
          {tasks.map((task) => (
            <TaskItem key={task.id} task={task} />
          ))}
        </ul>
      )}
    </main>
  );
}
