import { createContext, useCallback, useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useCollection } from '../hooks/useCollection';

export const TasksContext = createContext(null);

// Contexto 2: datos de las tareas, compartidos entre páginas
export function TasksProvider({ children }) {
  const { user } = useAuth();
  const uid = user?.uid;
  const { getAll, add, update, remove } = useCollection('tasks');

  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Carga las tareas del usuario actual cada vez que cambia la sesión
  const loadTasks = useCallback(async () => {
    if (!uid) {
      setTasks([]);
      return;
    }
    setLoading(true);
    setError('');
    try {
      const data = await getAll([['userId', '==', uid]]);
      setTasks(data.sort((a, b) => b.createdAt - a.createdAt));
    } catch {
      setError('No se pudieron cargar las tareas.');
    } finally {
      setLoading(false);
    }
  }, [uid, getAll]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const addTask = async (title, description) => {
    const data = { title, description, done: false, userId: uid, createdAt: Date.now() };
    const id = await add(data);
    setTasks((prev) => [{ id, ...data }, ...prev]);
  };

  const updateTask = async (id, changes) => {
    await update(id, changes);
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...changes } : t)));
  };

  const toggleTask = (task) => updateTask(task.id, { done: !task.done });

  const deleteTask = async (id) => {
    await remove(id);
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const value = { tasks, loading, error, addTask, updateTask, toggleTask, deleteTask };

  return <TasksContext.Provider value={value}>{children}</TasksContext.Provider>;
}
