import { createContext } from 'react';
import { useFirebaseAuth } from '../hooks/useFirebaseAuth';

export const AuthContext = createContext(null);

// Contexto 1: login / registro / sesión
export function AuthProvider({ children }) {
  const auth = useFirebaseAuth();
  return <AuthContext.Provider value={auth}>{children}</AuthContext.Provider>;
}
