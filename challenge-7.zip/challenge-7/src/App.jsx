import { Navigate, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import PrivateRoute from './components/PrivateRoute';
import PublicRoute from './components/PublicRoute';
import Login from './pages/Login';
import NotFound from './pages/NotFound';
import Register from './pages/Register';
import Tasks from './pages/Tasks';

export default function App() {
  return (
    <Routes>
      {/* Públicas (si ya hay sesión redirigen a /tasks) */}
      <Route element={<PublicRoute />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Route>

      {/* Privadas */}
      <Route element={<PrivateRoute />}>
        <Route element={<Navbar />}>
          <Route path="/tasks" element={<Tasks />} />
        </Route>
      </Route>

      <Route path="/" element={<Navigate to="/tasks" replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
