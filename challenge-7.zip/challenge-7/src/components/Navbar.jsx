import { Link, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

// Layout de las páginas privadas
export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  return (
    <>
      <nav className="navbar app-navbar">
        <div className="container">
          <Link to="/tasks" className="navbar-brand">
            ✅ Mis tareas
          </Link>
          <div className="d-flex align-items-center gap-3">
            <span className="text-white-50">
              Hola, <strong className="text-white">{user.displayName || user.email}</strong>
            </span>
            <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>
              Cerrar sesión
            </button>
          </div>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
