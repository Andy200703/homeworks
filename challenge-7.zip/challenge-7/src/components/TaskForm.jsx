import { useState } from 'react';
import { useTasks } from '../hooks/useTasks';

export default function TaskForm() {
  const { addTask } = useTasks();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (title.trim() === '') {
      setError('El título es obligatorio.');
      return;
    }
    setSaving(true);
    try {
      await addTask(title.trim(), description.trim());
      setTitle('');
      setDescription('');
      setError('');
    } catch {
      setError('No se pudo crear la tarea.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form className="card app-card p-3 mb-4" onSubmit={handleSubmit}>
      <h2 className="h5 mb-3">Nueva tarea</h2>
      <div className="mb-2">
        <input
          className="form-control"
          placeholder="Título"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>
      <div className="mb-3">
        <textarea
          className="form-control"
          rows="2"
          placeholder="Descripción (opcional)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>
      {error && <div className="alert alert-danger py-2">{error}</div>}
      <button className="btn btn-primary" type="submit" disabled={saving}>
        {saving ? 'Guardando...' : 'Crear tarea'}
      </button>
    </form>
  );
}
