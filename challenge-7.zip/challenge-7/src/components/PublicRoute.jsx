import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

// Login y Register: si ya hay sesión, se envía a /tasks
export default function PublicRoute() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="d-flex justify-content-center py-5">
        <div className="spinner-border text-primary" role="status" />
      </div>
    );
  }
  return user ? <Navigate to="/tasks" replace /> : <Outlet />;
}
