import { useState } from 'react';
import { useTasks } from '../hooks/useTasks';

export default function TaskItem({ task }) {
  const { toggleTask, updateTask, deleteTask } = useTasks();
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description);
  const [error, setError] = useState('');

  const run = async (action) => {
    try {
      setError('');
      await action();
    } catch {
      setError('No se pudo completar la acción.');
    }
  };

  const handleSave = () => {
    if (title.trim() === '') {
      setError('El título es obligatorio.');
      return;
    }
    run(async () => {
      await updateTask(task.id, { title: title.trim(), description: description.trim() });
      setEditing(false);
    });
  };

  const handleCancel = () => {
    setTitle(task.title);
    setDescription(task.description);
    setError('');
    setEditing(false);
  };

  if (editing) {
    return (
      <li className="list-group-item task-item">
        <input
          className="form-control mb-2"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          className="form-control mb-2"
          rows="2"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        {error && <div className="text-danger small mb-2">{error}</div>}
        <button className="btn btn-success btn-sm me-2" onClick={handleSave}>
          Guardar
        </button>
        <button className="btn btn-outline-secondary btn-sm" onClick={handleCancel}>
          Cancelar
        </button>
      </li>
    );
  }

  return (
    <li className={`list-group-item task-item ${task.done ? 'done' : ''}`}>
      <div className="d-flex align-items-start gap-3">
        <input
          className="form-check-input mt-1"
          type="checkbox"
          checked={task.done}
          onChange={() => run(() => toggleTask(task))}
          aria-label="Marcar como hecha"
        />
        <div className="flex-grow-1">
          <div className="task-title">{task.title}</div>
          {task.description && <div className="task-description">{task.description}</div>}
          {error && <div className="text-danger small">{error}</div>}
        </div>
        <div className="d-flex gap-2">
          <button className="btn btn-outline-primary btn-sm" onClick={() => setEditing(true)}>
            Editar
          </button>
          <button
            className="btn btn-outline-danger btn-sm"
            onClick={() => run(() => deleteTask(task.id))}
          >
            Eliminar
          </button>
        </div>
      </div>
    </li>
  );
}
