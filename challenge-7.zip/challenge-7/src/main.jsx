import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // librería CSS
import './styles/main.scss'; // nuestros estilos con SASS
import App from './App.jsx';
import { AuthProvider } from './context/AuthContext';
import { TasksProvider } from './context/TasksContext';

// AuthProvider va por fuera porque TasksProvider necesita saber quién es el usuario
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <TasksProvider>
          <App />
        </TasksProvider>
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>
);
