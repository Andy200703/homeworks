import { useMemo, useState } from 'react';
import TreeView from './components/TreeView';
import { BinaryTree } from './structures/BinaryTree';

// Serie inicial de números
const INITIAL_VALUES = [50, 30, 70, 20, 40, 60, 80, 35, 45, 65];

// Construye el árbol insertando los valores en orden
function buildTree(values) {
  const tree = new BinaryTree();
  values.forEach((value) => tree.insert(value));
  return tree;
}

export default function App() {
  const [values, setValues] = useState(INITIAL_VALUES);
  const [newValue, setNewValue] = useState('');
  const [searchValue, setSearchValue] = useState('');
  const [searched, setSearched] = useState(null); // { value, found }
  const [message, setMessage] = useState('');

  const tree = useMemo(() => {
    const t = buildTree(values);
    t.print(); // PreOrder, InOrder y PostOrder por consola
    return t;
  }, [values]);

  const handleInsert = (e) => {
    e.preventDefault();
    if (newValue.trim() === '' || Number.isNaN(Number(newValue))) {
      setMessage('Ingresa un número válido.');
      return;
    }
    const value = Number(newValue);
    if (tree.contains(value)) {
      setMessage(`El valor ${value} ya existe en el árbol (no se permiten repetidos).`);
      return;
    }
    setValues([...values, value]);
    setMessage(`Se insertó ${value}.`);
    setNewValue('');
    setSearched(null);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchValue.trim() === '' || Number.isNaN(Number(searchValue))) return;
    const value = Number(searchValue);
    setSearched({ value, found: tree.contains(value) });
  };

  return (
    <main className="container">
      <h1>Challenge 08 · Árbol binario</h1>

      <div className="grid">
        <form className="card" onSubmit={handleInsert}>
          <h2>Insertar valor</h2>
          <input
            type="number"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            placeholder="Ej: 55"
          />
          <button type="submit">Insertar</button>
          {message && <p className="muted">{message}</p>}
        </form>

        <form className="card" onSubmit={handleSearch}>
          <h2>Buscar valor</h2>
          <input
            type="number"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Ej: 45"
          />
          <button type="submit" className="secondary">
            Buscar
          </button>
          {searched && (
            <p className={searched.found ? 'ok' : 'error'}>
              {searched.found
                ? `El valor ${searched.value} SÍ está en el árbol.`
                : `El valor ${searched.value} NO está en el árbol.`}
            </p>
          )}
        </form>
      </div>

      <section className="card">
        <h2>Recorridos</h2>
        <p><strong>PreOrder (N-L-R):</strong> {tree.preOrder().join(', ')}</p>
        <p><strong>InOrder (L-N-R):</strong> {tree.inOrder().join(', ')}</p>
        <p><strong>PostOrder (L-R-N):</strong> {tree.postOrder().join(', ')}</p>
        <p className="muted">También se imprimen en la consola del navegador (F12).</p>
      </section>

      <section className="card">
        <h2>Árbol</h2>
        <TreeView data={tree.toD3Data()} highlight={searched?.found ? searched.value : null} />
      </section>
    </main>
  );
}
