import { useCallback, useState } from 'react';
import Tree from 'react-d3-tree';

// Dibuja cada nodo; el valor buscado se resalta en verde
function renderNode({ nodeDatum }, highlight) {
  const found = highlight !== null && nodeDatum.name === String(highlight);
  return (
    <g>
      <circle r="20" fill={found ? '#16a34a' : '#2f6fed'} stroke="#fff" strokeWidth="2" />
      <text
        fill="#fff"
        stroke="none"
        strokeWidth="0"
        textAnchor="middle"
        dy="5"
        fontSize="14"
        fontWeight="600"
      >
        {nodeDatum.name}
      </text>
    </g>
  );
}

export default function TreeView({ data, highlight }) {
  const [translate, setTranslate] = useState({ x: 0, y: 50 });

  // Centra la raíz según el ancho real del contenedor
  const containerRef = useCallback((element) => {
    if (element) {
      const { width } = element.getBoundingClientRect();
      setTranslate({ x: width / 2, y: 50 });
    }
  }, []);

  if (data === null) {
    return <p className="muted">El árbol está vacío.</p>;
  }

  return (
    <div className="tree-container" ref={containerRef}>
      <Tree
        data={data}
        translate={translate}
        orientation="vertical"
        pathFunc="straight"
        collapsible={false}
        zoomable
        nodeSize={{ x: 70, y: 90 }}
        separation={{ siblings: 1, nonSiblings: 1 }}
        renderCustomNodeElement={(props) => renderNode(props, highlight)}
      />
    </div>
  );
}
