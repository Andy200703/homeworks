// Nodo: valor + referencias al hijo izquierdo y derecho
export class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }

  // Una hoja es un nodo sin hijos
  isLeaf() {
    return this.left === null && this.right === null;
  }
}

// Árbol binario de búsqueda (no permite valores repetidos)
export class BinaryTree {
  constructor() {
    this.root = null;
  }

  // insert: menores a la izquierda, mayores a la derecha.
  // Devuelve false si el valor ya existe.
  insert(value) {
    const node = new TreeNode(value);
    if (this.root === null) {
      this.root = node;
      return true;
    }

    let current = this.root;
    while (true) {
      if (value === current.value) return false; // duplicado

      if (value < current.value) {
        if (current.left === null) {
          current.left = node;
          return true;
        }
        current = current.left;
      } else {
        if (current.right === null) {
          current.right = node;
          return true;
        }
        current = current.right;
      }
    }
  }

  // contains: true si el valor está en el árbol
  contains(value) {
    let current = this.root;
    while (current !== null) {
      if (value === current.value) return true;
      current = value < current.value ? current.left : current.right;
    }
    return false;
  }

  // PreOrder: Nodo - Izquierdo - Derecho
  preOrder(node = this.root, result = []) {
    if (node === null) return result;
    result.push(node.value);
    this.preOrder(node.left, result);
    this.preOrder(node.right, result);
    return result;
  }

  // InOrder: Izquierdo - Nodo - Derecho (queda ordenado de menor a mayor)
  inOrder(node = this.root, result = []) {
    if (node === null) return result;
    this.inOrder(node.left, result);
    result.push(node.value);
    this.inOrder(node.right, result);
    return result;
  }

  // PostOrder: Izquierdo - Derecho - Nodo
  postOrder(node = this.root, result = []) {
    if (node === null) return result;
    this.postOrder(node.left, result);
    this.postOrder(node.right, result);
    result.push(node.value);
    return result;
  }

  // Imprime los tres recorridos por consola
  print() {
    console.log('PreOrder :', this.preOrder().join(' - '));
    console.log('InOrder  :', this.inOrder().join(' - '));
    console.log('PostOrder:', this.postOrder().join(' - '));
  }

  // react-d3-tree espera { name, children: [...] }
  toD3Data(node = this.root) {
    if (node === null) return null;
    const data = { name: String(node.value) };
    const children = [node.left, node.right]
      .filter((child) => child !== null)
      .map((child) => this.toD3Data(child));
    if (children.length > 0) data.children = children;
    return data;
  }
}
